---
layout: post
title: "RIP nav; long live the navbar!"
published: false
---
